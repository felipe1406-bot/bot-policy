# Política de Privacidade

**Última atualização:** 16 de maio de 2025

Este bot Discord é um **simulador de jogos** voltado apenas para entretenimento.  
Ele **não coleta, armazena ou compartilha qualquer dado pessoal** dos usuários.

- **Dados coletados:** Nenhum.  
- **Armazenamento:** Nenhum dado é salvo fora do Discord.  
- **Compartilhamento:** Nenhum dado é compartilhado com terceiros.  
- **Contato:** Não há canal oficial de suporte no momento.  

Se houver mudanças no futuro, esta política será atualizada.

---

# Termos de Uso

**Última atualização:** 16 de maio de 2025

Ao utilizar este bot, você concorda com os seguintes termos:

- O bot é fornecido **como está**, sem garantias de funcionamento contínuo ou de resultados.  
- O bot é apenas para **entretenimento**, simula jogos virtuais sem recompensas reais.  
- O uso indevido do bot, como spam ou violações das regras do Discord, pode levar à suspensão do uso.  
- O criador do bot **não se responsabiliza por perdas, mal-entendidos ou problemas causados pelo uso** da ferramenta.  
- Nenhum dado pessoal é coletado.